package com.example.snowitall;

import java.util.ArrayList;
import java.util.List;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


public class MultipleChoiceQuestion {



}
