package com.example.snowitall;

public class Standard {

    // instance variables
    private VideoTutorial videoTutorial;
//    private Practice practice;
    private MasteryTest masteryTest;

    // constructor
//    public Standard(VideoTutorial videoTutorial, Practice practice, MasteryTest masteryTest) {
//        this.videoTutorial = videoTutorial;
//        this.practice = practice;
//        this.masteryTest = masteryTest;
//    }

    //getters and setters




//    // Create a scene graph
//    StackPane root = new StackPane();
//        root.getChildren().add(webView);
//
//    // Create a scene and add it to the stage
//    Scene scene = new Scene(root, 640, 480);
//        primaryStage.setScene(scene);
//        primaryStage.show();
//
//    // Play the video
//        webEngine.executeScript("document.getElementsByTagName('video')[0].play();");

}
