package com.example.snowitall;

import java.util.ArrayList;

public class Question {

//    private MultipleChoiceQuestion mcQuestion;

//    private TrueFalseQuestion tfQuestion;
//
//    private FillInBlankQuestion fibQuestion;

//    ArrayList<MultipleChoiceQuestion> questions = new ArrayList<MultipleChoiceQuestion>();

    //List to store true or false questions
//    private List<String> tfQuestions;

    //List to store fill in the blank questions
//    private List<String> fibQuestions;

 //   questions.add(q1 = new MultipleChoiceQuestion("What is 5 x 2 + (37 + 3 x 5) + 37?", "99","83", "75", "102", "99"));




//    public void storeQuestions(MultipleChoiceQuestion question) {
//
//        for (MultipleChoiceQuestion question_ : questions) {
//            questions.add(question);
//        }
//
//    }




}
