package com.example.snowitall;

public class VideoTutorial {

    private String currentStandard;


}
