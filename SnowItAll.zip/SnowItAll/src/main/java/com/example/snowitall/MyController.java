package com.example.snowitall;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class MyController {

    @FXML
    private Label label;

    private String labelText = "Initial Text";

    @FXML
    private void handleButtonAction(ActionEvent event) {
        label.setText(labelText);
    }

    @FXML
    public void updateLabelText(String text) {
        label.setText(text);
    }



//    public void setLabelText(String text) {
//        labelText = text;
//    }


}
