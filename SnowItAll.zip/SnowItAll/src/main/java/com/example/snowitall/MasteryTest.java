package com.example.snowitall;

public class MasteryTest {
}
