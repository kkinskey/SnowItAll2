package UI;

    public abstract class StandardControllerParent {
        public abstract void initialize();
//        public abstract void setCheckmarkBoolean(int checkmarkindex);
//
//        public Backend.Grade getGrade() {
//            return Database.getCurrentUserGradeClass();
//        }
    }
