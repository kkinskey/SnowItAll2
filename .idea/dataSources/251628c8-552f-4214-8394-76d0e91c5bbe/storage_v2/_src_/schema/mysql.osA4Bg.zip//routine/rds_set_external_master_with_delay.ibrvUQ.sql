create
    definer = rdsadmin@localhost procedure rds_set_external_master_with_delay(IN host varchar(255), IN port int,
                                                                              IN user text, IN passwd text,
                                                                              IN name text, IN pos mediumtext,
                                                                              IN enable_ssl_encryption tinyint(1),
                                                                              IN delay int)
BEGIN
  DECLARE v_rdsrepl INT;
  DECLARE v_mysql_version VARCHAR(20);
  DECLARE v_called_by_user VARCHAR(50);
  DECLARE sql_logging BOOLEAN;

  SELECT @@sql_log_bin, user(), version() INTO sql_logging, v_called_by_user, v_mysql_version;
  Select count(1) into v_rdsrepl FROM mysql.rds_history WHERE action = 'disable set master' AND master_user = 'rdsrepladmin';

  IF delay NOT BETWEEN 0 AND 86400 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'For source delay the value must be between 0 and 86400 inclusive.';
  ELSEIF v_rdsrepl > 0 and  v_called_by_user != 'rdsadmin@localhost' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Permission Denied: This instance is a RDS Read Replica.';
  END IF;

  
    BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN SET @@sql_log_bin=sql_logging; RESIGNAL; END;
    SET @@sql_log_bin=OFF;

    
    SET @cmd = CONCAT('CHANGE MASTER TO',
                      ' MASTER_HOST = ', QUOTE(TRIM(BOTH FROM host)),
                      ', MASTER_PORT = ', port,                               
                      ', MASTER_USER = ', QUOTE(TRIM(BOTH FROM user)),
                      ', MASTER_PASSWORD = ', QUOTE(TRIM(BOTH FROM passwd)),
                      ', MASTER_LOG_FILE = ', QUOTE(TRIM(BOTH FROM name)),
                      ', MASTER_LOG_POS = ', pos,                             
                      ', MASTER_SSL = ', enable_ssl_encryption,               
                      ', MASTER_AUTO_POSITION = 0',
                      ', MASTER_DELAY = ', delay                              
                      );
    PREPARE rds_set_master_with_delay FROM @cmd;
    update mysql.rds_replication_status set called_by_user=v_called_by_user, action='set master', mysql_version=v_mysql_version , master_host=trim(both from host), master_port=port where action is not null;
    commit;
    call mysql.rds_clean_replication_status;
    EXECUTE rds_set_master_with_delay;
    DEALLOCATE PREPARE rds_set_master_with_delay;
    INSERT INTO mysql.rds_history(called_by_user,action,mysql_version,master_host,master_port,master_user,master_log_file,master_log_pos,master_ssl,master_delay,auto_position)
           values (v_called_by_user,'set master',v_mysql_version,trim(both from host),port,trim(both from user),trim(both from name),pos,enable_ssl_encryption,delay, 0);
    commit;
    UPDATE mysql.rds_configuration
           SET mysql.rds_configuration.value = delay
           WHERE BINARY mysql.rds_configuration.name = 'source delay';
    commit;

    SET @@sql_log_bin=sql_logging;
  END;
END;

grant select on user to 'mysql.session'@localhost;

