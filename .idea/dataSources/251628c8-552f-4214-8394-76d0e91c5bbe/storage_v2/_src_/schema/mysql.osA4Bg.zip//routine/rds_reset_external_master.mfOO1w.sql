create
    definer = rdsadmin@localhost procedure rds_reset_external_master()
BEGIN
  DECLARE v_rdsrepl INT;
  DECLARE v_mysql_version VARCHAR(20);
  DECLARE v_called_by_user VARCHAR(50);
  DECLARE v_service_state ENUM('ON', 'OFF', 'BROKEN');
  DECLARE sql_logging BOOLEAN;
  SELECT @@sql_log_bin, user(), version(), mysql.rds_replication_service_state() INTO sql_logging, v_called_by_user, v_mysql_version, v_service_state;
  Select count(1) into v_rdsrepl from mysql.rds_history where action = 'disable set master' and master_user = 'rdsrepladmin';

  IF  v_rdsrepl > 0 and  v_called_by_user != 'rdsadmin@localhost'
  THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Permission Denied: This instance is a RDS Read Replica.';
  END IF;

  
  BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN SET @@sql_log_bin=sql_logging; RESIGNAL; END;
    SET @@sql_log_bin=OFF;

    IF v_service_state = 'OFF' 
    THEN
      update mysql.rds_replication_status set called_by_user=v_called_by_user, action='reset slave', mysql_version=v_mysql_version, master_host=NULL, master_port=NULL where action is not null;
      commit;
      call mysql.rds_clean_replication_status;
    ELSE 
      call mysql.rds_stop_replication;
      DO SLEEP(1);
      update mysql.rds_replication_status set called_by_user=v_called_by_user, action='reset slave', mysql_version=v_mysql_version, master_host=NULL, master_port=NULL where action is not null;
      commit;
      
      
      
      
      DO SLEEP(1);
    END IF;

    RESET SLAVE ALL;
    INSERT into mysql.rds_history(called_by_user, action, mysql_version) values (v_called_by_user,'reset slave', v_mysql_version);
    commit;
    Select 'Slave has been reset' as message;

    SET @@sql_log_bin=sql_logging;
  END;
END;

