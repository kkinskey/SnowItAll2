create
    definer = rdsadmin@localhost procedure rds_skip_repl_error()
BEGIN
  DECLARE v_service_state ENUM('ON', 'OFF', 'BROKEN');
  DECLARE v_called_by_user VARCHAR(50);
  DECLARE v_mysql_version VARCHAR(20);
  DECLARE sql_logging BOOLEAN;
  SELECT @@sql_log_bin, user(), version(), mysql.rds_replication_service_state() INTO sql_logging, v_called_by_user, v_mysql_version, v_service_state;

  IF v_service_state = 'ON' 
  then
    
    
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Slave is running normally.  No errors detected to skip.';
  elseif v_service_state = 'OFF' 
  then
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Slave is down or disabled.';
  else 
    STOP SLAVE;
    SET GLOBAL SQL_SLAVE_SKIP_COUNTER = 1;
    START SLAVE;
    Select 'Statement in error has been skipped' as Message;
    DO SLEEP(2);
    SELECT mysql.rds_replication_service_state() INTO v_service_state;

    
    BEGIN
      DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN SET @@sql_log_bin=sql_logging; RESIGNAL; END;
      SET @@sql_log_bin=OFF;

      if v_service_state = 'ON' then
        Select 'Slave is now running normally' as Message;
        INSERT into mysql.rds_history(called_by_user, action, mysql_version) values (v_called_by_user,'skip_repl_error:OK',v_mysql_version);
        commit;
      else
        INSERT into mysql.rds_history(called_by_user, action, mysql_version) values (v_called_by_user,'skip_repl_error:ERR',v_mysql_version);
        commit;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Slave has encountered a new error. Please use SHOW SLAVE STATUS to see the error.';
      end if;

      SET @@sql_log_bin=sql_logging;
    end;
  end if;
END;

